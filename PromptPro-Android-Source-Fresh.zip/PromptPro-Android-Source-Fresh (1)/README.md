# PromptPro Android v1.2
Features: adaptive audio-level voice-follow scroll, 1.5s silence pause, adjustable noisy-room sensitivity, manual controls, front/back camera toggle, camera preview with script overlay, video save to Gallery/Movies/PromptPro via MediaStore, and local script library storing full script text.

## Build APK
Open in Android Studio with Android SDK 35; allow Gradle sync; connect phone; choose Build > Build Bundle(s) / APK(s) > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Limitations and testing
This source has not been compiled or tested on a physical device here. Voice detection is an adaptive volume/noise-floor heuristic, not speech recognition or a trained VAD; loud noise/music can still cause false triggers. The prompt overlay is visible in the app preview for the presenter and is not burned into the saved video. Verify that CameraX records microphone audio on the target phone. Saved scripts are local to the app.
