
package com.promptpro.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.sqrt

private val bg = Color(0xFF090909)
private val panel = Color(0xFF171717)
private val gold = Color(0xFFD8B45A)
private val cream = Color(0xFFF4EBD7)

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = gold,
                    background = bg,
                    surface = panel,
                    onSurface = cream,
                    onBackground = cream
                )
            ) {
                PromptPro {
                    perms.launch(
                        arrayOf(
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO
                        )
                    )
                }
            }
        }
    }
}

private fun granted(c: Context, p: String): Boolean {
    return ContextCompat.checkSelfPermission(
        c, p
    ) == PackageManager.PERMISSION_GRANTED
}

private fun readScripts(c: Context): LinkedHashMap<String, String> {

    val raw = c.getSharedPreferences("pp", 0)
        .getString("scripts", null)
        ?: return linkedMapOf(
            "My first script" to
                "Namaskar dosto! Apni script yahan likhein."
        )

    return try {
        val j = JSONObject(raw)
        LinkedHashMap<String, String>().apply {
            j.keys().forEach { k ->
                put(k, j.optString(k))
            }
        }
    } catch (_: Exception) {
        linkedMapOf("My first script" to "")
    }
}

private fun writeScripts(
    c: Context,
    m: Map<String, String>
) {
    val j = JSONObject()
    m.forEach { (k, v) -> j.put(k, v) }

    c.getSharedPreferences("pp", 0)
        .edit()
        .putString("scripts", j.toString())
        .apply()
}

@Composable
fun PromptPro(requestPermissions: () -> Unit) {

    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current

    var library by remember {
        mutableStateOf(readScripts(ctx))
    }

    var selected by remember {
        mutableStateOf(library.keys.first())
    }

    var script by remember {
        mutableStateOf(library[selected] ?: "")
    }

    var newName by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }

    var camera by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var recording by remember { mutableStateOf(false) }

    var activeRecording by remember {
        mutableStateOf<Recording?>(null)
    }

    var running by remember { mutableStateOf(false) }
    var voiceMode by remember { mutableStateOf(true) }
    var voice by remember { mutableStateOf(false) }

    var sensitivity by remember { mutableFloatStateOf(.55f) }
    var speed by remember { mutableFloatStateOf(42f) }
    var font by remember { mutableFloatStateOf(30f) }

    var status by remember { mutableStateOf("Ready") }

    val scroll = rememberScrollState()

    val cam = remember(ctx) {
        LifecycleCameraController(ctx).apply {
            setEnabledUseCases(CameraController.VIDEO_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
        }
    }

    DisposableEffect(cam, owner) {
        cam.bindToLifecycle(owner)
        onDispose {
            activeRecording?.stop()
            cam.unbind()
        }
    }

    fun saveCurrent() {
        library = LinkedHashMap(library).apply {
            put(selected, script)
        }
        writeScripts(ctx, library)
        Toast.makeText(
            ctx, "Script saved", Toast.LENGTH_SHORT
        ).show()
    }

    // Voice detection: 1.5 second silence pause

    LaunchedEffect(running, voiceMode, sensitivity) {

        if (
            !running ||
            !voiceMode ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            voice = false
            return@LaunchedEffect
        }

        withContext(Dispatchers.IO) {

            val rate = 16000

            val size = AudioRecord.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                size * 2
            )

            try {

                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    status = "Microphone unavailable"
                    return@withContext
                }

                val buf = ShortArray(1024)
                var floor = -55.0
                var last = 0L

                rec.startRecording()

                while (isActive && running) {

                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue

                    var sum = 0.0

                    for (i in 0 until n) {
                        val x = buf[i].toDouble() / 32768.0
                        sum += x * x
                    }

                    val db = 20 * log10(
                        sqrt(sum / n).coerceAtLeast(.000001)
                    )

                    val threshold = maxOf(
                        -39 + (1 - sensitivity) * 9,
                        floor + 7 + (1 - sensitivity) * 9
                    )

                    if (db > threshold) {
                        last = System.currentTimeMillis()
                        voice = true
                        status = "Voice detected · scrolling"
                    } else {
                        floor = floor * .96 + db * .04

                        if (
                            System.currentTimeMillis() - last >= 1500
                        ) {
                            voice = false
                            status = "Paused · waiting for voice"
                        }
                    }

                    delay(35)
                }

            } catch (_: SecurityException) {
                status = "Microphone permission required"
            } finally {
                try {
                    rec.stop()
                } catch (_: Exception) {}
                rec.release()
            }
        }
    }

    // Automatic scrolling

    LaunchedEffect(running, voice, voiceMode, speed) {

        while (isActive && running) {

            if (!voiceMode || voice) {
                scroll.scrollBy(speed / 60f)
            }

            delay(16)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        // Header

        Row(verticalAlignment = Alignment.CenterVertically) {

            Column(Modifier.weight(1f)) {
                Text(
                    "PROMPTPRO",
                    color = gold,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    "SMART VOICE TELEPROMPTER",
                    color = cream.copy(alpha = .6f),
                    fontSize = 10.sp
                )
            }

            Text(
                if (voice) "VOICE ON" else "STANDBY",
                color = gold,
                fontWeight = FontWeight.Bold
            )
        }

        // Camera Preview

        if (camera) {

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(330.dp)
                    .background(Color.Black)
            ) {

                if (granted(ctx, Manifest.permission.CAMERA)) {

                    AndroidView(
                        factory = {
                            PreviewView(it).apply {
                                scaleType =
                                    PreviewView.ScaleType.FILL_CENTER
                                controller = cam
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    Column(
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .height(240.dp)
                            .background(Color.Black.copy(alpha = .38f))
                            .verticalScroll(scroll)
                            .padding(14.dp)
                    ) {
                        Text(
                            script,
                            color = Color.White,
                            fontSize = (font * .65f).sp,
                            lineHeight = (font * .95f).sp
                        )
                        Spacer(Modifier.height(180.dp))
                    }

                } else {

                    Text(
                        "Camera permission required",
                        color = cream,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                OutlinedButton(
                    onClick = {
                        front = !front
                        cam.cameraSelector =
                            if (front)
                                CameraSelector.DEFAULT_FRONT_CAMERA
                            else
                                CameraSelector.DEFAULT_BACK_CAMERA
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        if (front) "FRONT CAMERA" else "BACK CAMERA",
                        color = gold
                    )
                }

                Button(
                    onClick = {

                        if (
                            !granted(ctx, Manifest.permission.CAMERA) ||
                            !granted(ctx, Manifest.permission.RECORD_AUDIO)
                        ) {
                            requestPermissions()

                        } else if (!recording) {

                            val stamp = SimpleDateFormat(
                                "yyyyMMdd_HHmmss",
                                Locale.US
                            ).format(Date())

                            val values = ContentValues().apply {
                                put(
                                    MediaStore.Video.Media.DISPLAY_NAME,
                                    "PromptPro_$stamp.mp4"
                                )
                                put(
                                    MediaStore.Video.Media.MIME_TYPE,
                                    "video/mp4"
                                )
                                put(
                                    MediaStore.Video.Media.RELATIVE_PATH,
                                    "Movies/PromptPro"
                                )
                            }

                            val output = MediaStoreOutputOptions.Builder(
                                ctx.contentResolver,
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            )
                                .setContentValues(values)
                                .build()

                            try {

                                activeRecording = cam.startRecording(
                                    output,
                                    ContextCompat.getMainExecutor(ctx)
                                ) { event: VideoRecordEvent ->

                                    when (event) {

                                        is VideoRecordEvent.Start -> {
                                            recording = true
                                            status = "Recording…"
                                        }

                                        is VideoRecordEvent.Finalize -> {
                                            recording = false
                                            activeRecording = null

                                            status =
                                                if (event.hasError())
                                                    "Recording failed"
                                                else
                                                    "Saved to Gallery / Movies / PromptPro"

                                            Toast.makeText(
                                                ctx,
                                                status,
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    }
                                }

                            } catch (e: Exception) {
                                status =
                                    "Cannot start recording: ${e.localizedMessage}"
                            }

                        } else {
                            activeRecording?.stop()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor =
                            if (recording) Color.Red else gold,
                        contentColor = Color.Black
                    )
                ) {
                    Text(if (recording) "STOP REC" else "RECORD")
                }
            }

            OutlinedButton(
                onClick = {
                    activeRecording?.stop()
                    camera = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("CLOSE CAMERA", color = cream)
            }

        } else {

            Surface(
                color = panel,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(scroll)
                        .padding(18.dp)
                ) {
                    Text(
                        script,
                        color = cream,
                        fontSize = font.sp,
                        lineHeight = (font * 1.45f).sp
                    )
                    Spacer(Modifier.height(200.dp))
                }
            }
        }

        Text(status, color = gold, fontSize = 12.sp)

        // Start and Stop controls

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Button(
                onClick = {
                    if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) {
                        requestPermissions()
                    } else {
                        running = !running
                        status =
                            if (running) "Listening…" else "Stopped"
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = gold,
                    contentColor = bg
                )
            ) {
                Text(if (running) "PAUSE" else "START")
            }

            OutlinedButton(
                onClick = {
                    running = false
                    voice = false
                    status = "Stopped"
                }
            ) {
                Text("STOP", color = cream)
            }
        }

        // Settings

        Surface(
            color = panel,
            shape = MaterialTheme.shapes.large
        ) {

            Column(Modifier.padding(14.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Voice-follow mode",
                        modifier = Modifier.weight(1f),
                        color = cream
                    )
                    Switch(
                        voiceMode,
                        { voiceMode = it }
                    )
                }

                Text(
                    "Noisy-room sensitivity",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    sensitivity,
                    { sensitivity = it }
                )

                Text(
                    "Scroll speed",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    speed,
                    { speed = it },
                    valueRange = 10f..110f
                )

                Text(
                    "Text size",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    font,
                    { font = it },
                    valueRange = 20f..48f
                )
            }
        }

        // Script controls

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            OutlinedButton(
                onClick = {
                    editor = !editor
                    showLibrary = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("SCRIPT EDITOR", color = gold)
            }

            OutlinedButton(
                onClick = {
                    showLibrary = !showLibrary
                    editor = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("MY SCRIPTS", color = gold)
            }
        }

        Button(
            onClick = {
                if (!granted(ctx, Manifest.permission.CAMERA)) {
                    requestPermissions()
                } else {
                    camera = true
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = gold,
                contentColor = bg
            )
        ) {
            Text("OPEN CAMERA")
        }

        // Script editor

        if (editor) {

            Text(
                "EDITING: $selected",
                color = gold,
                fontWeight = FontWeight.Bold
            )

            BasicTextField(
                script,
                { script = it },
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(panel)
                    .padding(12.dp),
                textStyle = TextStyle(
                    color = cream,
                    fontSize = 15.sp
                )
            )

            OutlinedButton(
                onClick = { saveCurrent() }
            ) {
                Text("SAVE SCRIPT", color = gold)
            }
        }

        // Script library

        if (showLibrary) {

            Row(verticalAlignment = Alignment.CenterVertically) {

                BasicTextField(
                    newName,
                    { newName = it },
                    Modifier
                        .weight(1f)
                        .background(panel)
                        .padding(10.dp),
                    textStyle = TextStyle(color = cream)
                )

                Button(
                    onClick = {
                        val n = newName.trim()

                        if (n.isNotEmpty() && !library.containsKey(n)) {

                            library = LinkedHashMap(library).apply {
                                put(n, "")
                            }

                            writeScripts(ctx, library)
                            selected = n
                            script = ""
                            newName = ""
                            editor = true
                            showLibrary = false
                        }
                    }
                ) {
                    Text("ADD")
                }
            }

            library.forEach { (name, body) ->

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Column(Modifier.weight(1f)) {
                        Text(name, color = cream)
                        Text(
                            "${body.length} characters",
                            color = cream.copy(alpha = .5f),
                            fontSize = 10.sp
                        )
                    }

                    TextButton(
                        onClick = {
                            saveCurrent()
                            selected = name
                            script = library[name] ?: ""
                            editor = true
                            showLibrary = false
                        }
                    ) {
                        Text("OPEN", color = gold)
                    }

                    TextButton(
                        onClick = {

                            library = LinkedHashMap(library).apply {
                                remove(name)
                            }

                            writeScripts(ctx, library)

                            if (selected == name) {
                                selected =
                                    library.keys.firstOrNull() ?: "New"
                                script = library[selected] ?: ""
                            }
                        }
                    ) {
                        Text("DELETE", color = Color.Red)
                    }
                }
            }
        }

        Text(
            "1.5s silence pause · local script storage · Gallery export",
            color = cream.copy(alpha = .45f),
            fontSize = 10.sp
        )
    }
}
