# PromptPro Android v1.2
Features: adaptive audio-level voice-follow scroll, 1.5s silence pause, adjustable noisy-room sensitivity, manual controls, front/back camera toggle, camera preview with script overlay, video save to Gallery/Movies/PromptPro via MediaStore, and local script library storing full script text.

## Build APK
Open in Android Studio with Android SDK 35; allow Gradle sync; connect phone; choose Build > Build Bundle(s) / APK(s) > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Limitations and testing
This source has not been compiled or tested on a physical device here. Voice detection is an adaptive volume/noise-floor heuristic, not speech recognition or a trained VAD; loud noise/music can still cause false triggers. The prompt overlay is visible in the app preview for the presenter and is not burned into the saved video. Verify that CameraX records microphone audio on the target phone. Saved scripts are local to the app.

## Build APK automatically with GitHub Actions
This project includes `.github/workflows/android-apk.yml`.
1. Create a GitHub repository and upload/push the contents of this project to its `main` branch.
2. Open the repository's **Actions** tab and run **Build PromptPro APK** (or let the push trigger it).
3. When the workflow succeeds, open its run and download the `PromptPro-debug-apk` artifact.
4. Extract `app-debug.apk` and install it on your Android phone, allowing installation from that source if Android asks.

This workflow has been provided but has not been run from this environment; successful compilation and device behavior still need verification.
